ofxCv
ofxGui
ofxOpenCv
