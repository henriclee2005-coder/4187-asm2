#include "ofApp.h"
using namespace cv;
using namespace ofxCv;
//--------------------------------------------------------------
void ofApp::setup(){
	// 1. Setup Webcam (Tutorial Page 14)
	vidGrabber.initGrabber(640, 480); // Use a standard resolution

	// 2. Setup SIFT (Tutorial Page 6)
	sift = cv::SIFT::create(400);

	// 3. Load Templates and Extract SIFT Features (Once, to save CPU)
	roadImg.load("road.png");
	bridgeImg.load("bridge.png");

	cv::Mat roadMat = ofxCv::toCv(roadImg);
	cv::Mat bridgeMat = ofxCv::toCv(bridgeImg);

	sift->detectAndCompute(roadMat, cv::noArray(), roadKp, roadDesc);
	sift->detectAndCompute(bridgeMat, cv::noArray(), bridgeKp, bridgeDesc);

	// 4. Load Video Clips (Requirement 2)
	roadVideo.load("road.mp4");
	bridgeVideo.load("bridge.mp4");
	roadVideo.play();
	bridgeVideo.play();

}

//--------------------------------------------------------------
void ofApp::update(){
	vidGrabber.update();

	if (vidGrabber.isFrameNew()) {
		im.setFromPixels(vidGrabber.getPixels());
		mat = ofxCv::toCv(im);

		std::vector<cv::KeyPoint> webcamKp;
		cv::Mat webcamDesc;
		sift->detectAndCompute(mat, cv::noArray(), webcamKp, webcamDesc);

		if (webcamKp.empty()) return;

		cv::BFMatcher matcher(cv::NORM_L2);

		// ==========================================
		// ROAD MATCHING & HOMOGRAPHY
		// ==========================================
		std::vector<cv::DMatch> roadMatches;
		matcher.match(roadDesc, webcamDesc, roadMatches);

		std::vector<cv::Point2f> roadSrcPoints; // Points on road.png
		std::vector<cv::Point2f> roadDstPoints; // Points on webcam

		for (size_t i = 0; i < roadMatches.size(); i++) {
			if (roadMatches[i].distance < 150.0f) { // Keep good matches
				roadSrcPoints.push_back(roadKp[roadMatches[i].queryIdx].pt);
				roadDstPoints.push_back(webcamKp[roadMatches[i].trainIdx].pt);
			}
		}

		// Need at least 4 points to calculate Homography
		if (roadSrcPoints.size() >= 4) {
			// Find the transformation matrix using RANSAC (filters out bad outliers)
			roadH = cv::findHomography(roadSrcPoints, roadDstPoints, cv::RANSAC);

			if (!roadH.empty()) {
				// Define the 4 corners of the original road.png
				std::vector<cv::Point2f> roadTemplateCorners = {
					cv::Point2f(0, 0),
					cv::Point2f((float)roadImg.getWidth(), 0),
					cv::Point2f((float)roadImg.getWidth(), (float)roadImg.getHeight()),
					cv::Point2f(0, (float)roadImg.getHeight())
				};

				// Map those corners to the webcam image
				cv::perspectiveTransform(roadTemplateCorners, roadCorners, roadH);
				roadFound = true;
			}
		} else {
			roadFound = false;
		}

		// ==========================================
		// BRIDGE MATCHING & HOMOGRAPHY (Same logic)
		// ==========================================
		std::vector<cv::DMatch> bridgeMatches;
		matcher.match(bridgeDesc, webcamDesc, bridgeMatches);

		std::vector<cv::Point2f> bridgeSrcPoints;
		std::vector<cv::Point2f> bridgeDstPoints;

		for (size_t i = 0; i < bridgeMatches.size(); i++) {
			if (bridgeMatches[i].distance < 150.0f) {
				bridgeSrcPoints.push_back(bridgeKp[bridgeMatches[i].queryIdx].pt);
				bridgeDstPoints.push_back(webcamKp[bridgeMatches[i].trainIdx].pt);
			}
		}

		if (bridgeSrcPoints.size() >= 4) {
			bridgeH = cv::findHomography(bridgeSrcPoints, bridgeDstPoints, cv::RANSAC);

			if (!bridgeH.empty()) {
				std::vector<cv::Point2f> bridgeTemplateCorners = {
					cv::Point2f(0, 0),
					cv::Point2f((float)bridgeImg.getWidth(), 0),
					cv::Point2f((float)bridgeImg.getWidth(), (float)bridgeImg.getHeight()),
					cv::Point2f(0, (float)bridgeImg.getHeight())
				};

				cv::perspectiveTransform(bridgeTemplateCorners, bridgeCorners, bridgeH);
				bridgeFound = true;
			}
		} else {
			bridgeFound = false;
		}
	}

	roadVideo.update();
	bridgeVideo.update();
}

//--------------------------------------------------------------
void ofApp::draw(){
	vidGrabber.draw(0, 0);

	// Helper lambda to draw video into a quad mesh
	auto drawVideoInQuad = [](ofVideoPlayer & video, const std::vector<cv::Point2f> & corners) {
		if (corners.size() == 4) {
			ofMesh mesh;
			mesh.setMode(OF_PRIMITIVE_TRIANGLE_FAN); // Draws a quad

			// Add the 4 corners of the screen position
			mesh.addVertex(glm::vec3(corners[0].x, corners[0].y, 0));
			mesh.addVertex(glm::vec3(corners[1].x, corners[1].y, 0));
			mesh.addVertex(glm::vec3(corners[2].x, corners[2].y, 0));
			mesh.addVertex(glm::vec3(corners[3].x, corners[3].y, 0));

			// Map the video texture coordinates to the corners (Top-Left, Top-Right, Bottom-Right, Bottom-Left)
			mesh.addTexCoord(glm::vec2(0, 0));
			mesh.addTexCoord(glm::vec2(video.getWidth(), 0));
			mesh.addTexCoord(glm::vec2(video.getWidth(), video.getHeight()));
			mesh.addTexCoord(glm::vec2(0, video.getHeight()));

			// Bind video texture and draw
			video.getTexture().bind();
			mesh.draw();
			video.getTexture().unbind();
		}
	};

	// Draw Road
	if (roadFound) {
		drawVideoInQuad(roadVideo, roadCorners);

		// Draw green outline to match the demo
		ofNoFill();
		ofSetColor(0, 255, 0); // Green
		ofDrawLine(roadCorners[0].x, roadCorners[0].y, roadCorners[1].x, roadCorners[1].y);
		ofDrawLine(roadCorners[1].x, roadCorners[1].y, roadCorners[2].x, roadCorners[2].y);
		ofDrawLine(roadCorners[2].x, roadCorners[2].y, roadCorners[3].x, roadCorners[3].y);
		ofDrawLine(roadCorners[3].x, roadCorners[3].y, roadCorners[0].x, roadCorners[0].y);
	}

	// Draw Bridge
	if (bridgeFound) {
		drawVideoInQuad(bridgeVideo, bridgeCorners);

		// Draw green outline
		ofNoFill();
		ofSetColor(0, 255, 0);
		ofDrawLine(bridgeCorners[0].x, bridgeCorners[0].y, bridgeCorners[1].x, bridgeCorners[1].y);
		ofDrawLine(bridgeCorners[1].x, bridgeCorners[1].y, bridgeCorners[2].x, bridgeCorners[2].y);
		ofDrawLine(bridgeCorners[2].x, bridgeCorners[2].y, bridgeCorners[3].x, bridgeCorners[3].y);
		ofDrawLine(bridgeCorners[3].x, bridgeCorners[3].y, bridgeCorners[0].x, bridgeCorners[0].y);
	}

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
