#pragma once

#include "ofMain.h"
#include "ofxCv.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		 ofVideoGrabber vidGrabber;
		ofImage im;
		cv::Mat mat;
		cv::Ptr<cv::SIFT> sift;

		// --- Target Templates (Requirement 1) ---
		ofImage roadImg, bridgeImg;
		cv::Mat roadDesc, bridgeDesc;
		std::vector<cv::KeyPoint> roadKp, bridgeKp;

		// --- Target Videos (Requirement 2) ---
		ofVideoPlayer roadVideo, bridgeVideo;

		// --- Bounding Boxes for Rendering ---
		cv::Rect roadBox;
		cv::Rect bridgeBox;
		bool roadFound = false;
		bool bridgeFound = false;

		// Homography Matrices
		cv::Mat roadH, bridgeH;

		// Arrays to store the 4 corners of the detected targets
		std::vector<cv::Point2f> roadCorners, bridgeCorners;

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		
};
